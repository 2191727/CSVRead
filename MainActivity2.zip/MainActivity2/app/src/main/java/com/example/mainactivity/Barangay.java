package com.example.mainactivity;

public class Barangay {

    private String Barangay;
    private int NewCases;
    private int ActiveCases;
    private int TotalCases;
    private int Deaths;
    private int Recoveries;
    private String LockdownInformation;

    public String getBarangay() {
        return Barangay;
    }

    public void setBarangay(String barangay) {
        Barangay = barangay;
    }

    public int getNewCases(int i) {
        return NewCases;
    }

    public void setNewCases(int newCases) {
        NewCases = newCases;
    }

    public int getActiveCases(int i) {
        return ActiveCases;
    }

    public void setActiveCases(int activeCases) {
        ActiveCases = activeCases;
    }

    public int getTotalCases(int i) {
        return TotalCases;
    }

    public void setTotalCases(int totalCases) {
        TotalCases = totalCases;
    }

    public int getDeaths(int i) {
        return Deaths;
    }

    public void setDeaths(int deaths) {
        Deaths = deaths;
    }

    public int getRecoveries(int i) {
        return Recoveries;
    }

    public void setRecoveries(int recoveries) {
        Recoveries = recoveries;
    }

    public String getLockdownInformation(String token) {
        return LockdownInformation;
    }

    public void setLockdownInformation(String lockdownInformation) {
        LockdownInformation = lockdownInformation;
    }

    @Override
    public String toString() {
        return "Barangay{" +
                "Barangay='" + Barangay + '\'' +
                ", NewCases=" + NewCases +
                ", ActiveCases=" + ActiveCases +
                ", TotalCases=" + TotalCases +
                ", Deaths=" + Deaths +
                ", Recoveries=" + Recoveries +
                ", LockdownInformation='" + LockdownInformation + '\'' +
                '}';
    }
}
