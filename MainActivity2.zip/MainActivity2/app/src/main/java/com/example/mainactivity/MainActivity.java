package com.example.mainactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        readBarangayData();

    }

    private List<Barangay> Barangay = new ArrayList<>();
    private void readBarangayData() {
        InputStream is = getResources().openRawResource(R.raw.data);
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(is, Charset.forName("UTF-8"))
        );


        String line = "";
            try {
                if (!((line = reader.readLine()) != null)) {
                    //Split by ','
                    String[] tokens = line.split(",");

                    //Read the Data
                    Barangay sample = new Barangay();
                    sample.setBarangay(tokens[0]);
                    sample.setNewCases(Integer.parseInt(tokens[1]));
                    sample.setActiveCases(Integer.parseInt(tokens[2]));
                    sample.setTotalCases(Integer.parseInt(tokens[3]));
                    sample.setDeaths(Integer.parseInt(tokens[4]));
                    sample.setRecoveries(Integer.parseInt(tokens[5]));
                    sample.setLockdownInformation(tokens[6]);
                    Barangay.add(sample);

                    Log.d("MyActivity", "Just Created: " + sample);

                }
            } catch (IOException e) {
                Log.wtf("MyActivity", "Error reading data file on line" + line, e);
                e.printStackTrace();
            }


    }
}